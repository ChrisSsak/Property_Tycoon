/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package propertytycoon;
//package monopolyGame;
import java.util.Scanner;

public class Card
{
	public Card(String anAction)
	{
		action = anAction;
	}
	
	public String getAction()
	{
		return action;
	}
	
	public void affect(Player p)
	{ if (action.equals("Bank pays you divided of 50")){p.earn(50);};
          if (action.equals("you have won a lip sync battle. Collect 100")){p.earn(100);};
          if (action.equals("Advance to Turing Heights")){p.setLoc(39);};
          if (action.equals("Advance to Han Xin Gardens.If you pass GO, collect 200")){if (p.getLoc()<24){p.setLoc(24);}else{p.setLoc(24);p.earn(200);}};
          if (action.equals("Fined 15 for speeding")){p.pay(15);};
          if (action.equals("Pay university fees of 150")){p.pay(150);};
          if (action.equals("Take a trip to Hove Station. If you pass GO collect 200")){if (p.getLoc()<15){p.setLoc(15);}else{p.setLoc(15);p.earn(200);}};
          if (action.equals("Loan matures,collect 150")){p.earn(150);};
          if (action.equals("You are assesed for repairs, 40/house, 115/hotel")){};////////////////////TODO
          if (action.equals("Advance to GO")){p.setLoc(0);};
          if (action.equals("You are assessed for repairs, 25/house,100/hotel")){};/////////////////TODO
          if (action.equals("Go back 3 spaces")){p.move(-3);};
          if (action.equals("Advance to Skywalker Drive. If you pass GO collect 200")){if (p.getLoc()<11){p.setLoc(11);}else{p.setLoc(11);p.earn(200);}};
          if (action.equals("Go to jail. Do not pass GO, do not collect 200")){p.jail();};
          if (action.equals("Drunk in charge of a skateboard. Fine 20")){p.pay(20);};
          if (action.equals("Get out of jail free")){p.giveCard(this);};
	
          if (action.equals("You inherit 100")){p.earn(100);};
          if (action.equals("You have won 2nd prize in a beauty contest, collect 200")){p.earn(200);};
          if (action.equals("Go back to Crapper Street")){p.setLoc(1);};
          if (action.equals("Student loan refund. Collect 20")){p.earn(20);};
          if (action.equals("Bank error in your favour. Collect 200")){p.earn(200);};
          if (action.equals("Pay bill for text books of 100")){p.pay(100);};
          if (action.equals("Mega late night taxi bill pay 50")){p.pay(50);};
          if (action.equals("Advance to GO")){p.setLoc(0);};
          if (action.equals("From sale of Bitcoin you get 50")){p.earn(50);};
          ////////////TODO
          if (action.equals("Pay a 10 fine or take opportunity knocks")){Scanner myObj = new Scanner(System.in); System.out.println("pay fine? yes/no"); String reply = myObj.nextLine();if(reply.equals("yes")){p.pay(50);}else{}};
          if (action.equals("Pay insurance fee of 50")){p.pay(50);};
          if (action.equals("Savings bond matures,collect 100")){p.earn(100);};
          if (action.equals("Go to jail. Do not pass GO, do not collect 200")){p.jail();};
          if (action.equals("Received interest on shares of 25")){p.earn(25);};
          if (action.equals("Its your birthday. Collect 10 from each player")){};//////////TODO
          if (action.equals("Get out of jail free")){p.giveCard(this);};
	}
	
	private String action;
}
